/*Addition

//Prompt - Alert
var d = 10;
//console.log("You have entered value of: " + d)
let e = d * d;
// alert(e);
//console.log("Sqaure root value of " + d + " is " + e);

var a, b;
var a = d;
var b = 6;
//console.log("Calc output = ", a * b + b);

//Function

// window.onload = addi;

function addi() {
    let a1 = 10,
        b1 = 20,
        c1 = 20;
    let d1 = a1 + b1 + c1;
    //console.log("Addition of a1 + b1 + c1 = ", d1);
}
addi();

/*
var f = addi();
let g = f - 10;
//console.log("e = d1 - 10 ", g);
*/
/*
let firstname = "John"
let lastname = "Nick"
    //console.log("First name : ", firstname, " & Last name : ", lastname)

//Before declaring
//console.log(z);
//After declaring
var z = 15;
//console.log(z);

//for loop & checking var i usage after for loop block
for (var i = 0; i <= 4; i++) {
    //console.log(i);
}
//console.log(i + 5);

// Function Invoke with different method

function mphTokmph(mph) {
    //console.log("MPH value entered : ", mph);
    return 1.61 * mph;
}
let speedLimit = mphTokmph(65);
//console.log("Speed Limit in Kmph", speedLimit);

let mphTokmphArrow = mph => {
    //console.log("MPH value entered : ", mph);
    return 1.61 * mph;
}
speedLimit = mphTokmphArrow(65);
//console.log("Speed Limit in Kmph", speedLimit);

let mphTokmphImplicit = mph => 1.61 * mph;
speedLimit = mphTokmphImplicit(65);
//console.log("Speed Limit in Kmph", speedLimit);

// Function copy

let multiply = (x, y) => 2 + x * y;
//console.log("Result of 2 + x * y : ", multiply(9, 8));

let functioncopy = multiply;
//console.log("Result of 2 + x * y : ", functioncopy(10, 10));

//let f = prompt("Enter Farienheit value: ");
let f = 50;
var def = function(f) { return 5 * (f - 32) / 9 };
//console.log(f, " Farienheit value is: ", def(f));

//******************************

// Math functions by On-click
function addi(var1, var2) {
    sumtot = var1 + var2;
    //console.log("Addiotion Result = ", sumtot);
}

function subtrac() {
    var val1 = prompt("Enter Value Val1: ");
    var val2 = prompt("Enter Value Val2: ");
    //subtot = val1 - val2;
    //console.log("Subtraction Result = ", val1 - val2);
}

function multi() {
    var val1 = 10,
        val2 = 15;
    multitot = val1 * val2;
    //console.log("Multiplication Result = ", multitot);
}

function divide() {
    var val1 = 105,
        val2 = 15;
    divtot = val1 / val2;
    //console.log("Division Result = ", divtot);
}

function sqrt() {
    var val1 = prompt("Enter Value to find out: ");
    sqrttot = Math.sqrt(val1);
    //console.log("SQ Root Result = ", sqrttot);
}

function mathfun(respval) {
    if (respval == "add") {
        addi(105, 100);
    } else if (respval == "sub") {
        subtrac();
    } else if (respval == "mul") {
        multi();
    } else if (respval == "divi") {
        divide();
    } else
        sqrt();
}

//Add or Even number

function EvenOdd() {
    var a;
    a = document.getElementById("num").value;
    if ((a % 2) == 0) {}
    //console.log("Given number is Even number");
    else {
        console.log("Given number is Odd number");
    }
}



// Calcualation by giving input in text box

function adding(add1, add2) {
    return add1 + add2;
}

function minus(min1, min2) {
    return min1 - min2;
}

function multiplied(mul1, mul2) {
    return mul1 * mul2;
}

function divide(div1, div2) {
    return div1 / div2;
}
var mathop = "add";

function myselect(resval) {
    alert(resval );
    mathop = document.getElementById("opt").value;
}

function calcmath() {

    var inpt1 = document.getElementById("input1").value;
    var inpt2 = document.getElementById("input2").value;

    if (mathop == "add") {
        var op1 = adding(Number(inpt1), Number(inpt2));
        document.getElementById("output1").value = Number(op1);

    } else if (mathop == "minus") {
        var op1 = minus(inpt1, inpt2);
        document.getElementById("output1").value = Number(op1);

    } else if (mathop == "multi") {
        var op1 = multiplied(inpt1, inpt2);
        document.getElementById("output1").value = Number(op1);

    } else {
        var op1 = divide(inpt1, inpt2);
        document.getElementById("output1").value = Number(op1);

    }
}

*/